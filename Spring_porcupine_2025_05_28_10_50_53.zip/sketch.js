function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let sunX = 0;
let clouds = [];
let tractor;
let seedlings = [];

function setup() {
  createCanvas(800, 600);
  sunX = 0;

  // Criar nuvens aleatórias
  for (let i = 0; i < 5; i++) {
    clouds.push({ x: random(width), y: random(50, 150) });
  }

  // Posição inicial do trator
  tractor = { x: width / 2, y: 450 };
}

function draw() {
  background(135, 206, 235); // Céu azul

  drawSun();
  drawClouds();
  drawField();
  drawTractor();
  drawSeedlings();
  drawText();
}

function drawSun() {
  fill(255, 204, 0);
  ellipse(sunX, 100, 80, 80);
  sunX += 0.5;
  if (sunX > width + 40) {
    sunX = -40;
  }
}

function drawClouds() {
  fill(255);
  noStroke();
  for (let c of clouds) {
    ellipse(c.x, c.y, 60, 60);
    ellipse(c.x + 30, c.y + 10, 50, 50);
    ellipse(c.x - 30, c.y + 10, 50, 50);
    c.x += 0.3;
    if (c.x > width + 60) {
      c.x = -60;
    }
  }
}

function drawField() {
  fill(34, 139, 34);
  rect(0, 500, width, 100);
}

function drawTractor() {
  // Corpo
  fill(200, 0, 0);
  rect(tractor.x, tractor.y, 60, 30);
  rect(tractor.x + 15, tractor.y - 20, 30, 20);

  // Rodas
  fill(50);
  ellipse(tractor.x + 10, tractor.y + 30, 20, 20);
  ellipse(tractor.x + 50, tractor.y + 30, 30, 30);
}

function drawSeedlings() {
  for (let s of seedlings) {
    fill(139, 69, 19);
    rect(s.x, s.y, 5, 15); // caule

    fill(0, 128, 0);
    ellipse(s.x - 5, s.y, 10, 10); // folha esquerda
    ellipse(s.x + 5, s.y, 10, 10); // folha direita
  }
}

function drawText() {
  fill(255);
  rect(10, 10, 380, 40, 10);
  fill(0);
  textSize(16);
  text("Agrinho 2025: Tecnologia e Sustentabilidade no Campo", 20, 35);
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    tractor.x -= 5;
  } else if (keyCode === RIGHT_ARROW) {
    tractor.x += 5;
  }
}

function mousePressed() {
  if (mouseY > 500) {
    seedlings.push({ x: mouseX, y: mouseY - 15 });
  }
}